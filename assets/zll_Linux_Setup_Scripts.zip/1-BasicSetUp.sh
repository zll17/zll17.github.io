#!/bin/bash

## 定义系统判定变量
DebianRelease="lsb_release"
ARCH=$(uname -m)
SYSTEM_DEBIAN="Debian"
SYSTEM_UBUNTU="Ubuntu"
SYSTEM_KALI="Kali"
SYSTEM_REDHAT="RedHat"
SYSTEM_RHEL="RedHat"
SYSTEM_CENTOS="CentOS"
SYSTEM_FEDORA="Fedora"
PKG_MGR=apt-get

## 定义目录和文件
LinuxRelease=/etc/os-release
RedHatRelease=/etc/redhat-release
DebianVersion=/etc/debian_version
DebianSourceList=/etc/apt/sources.list
DebianSourceListBackup=/etc/apt/sources.list.bak
DebianExtendListDir=/etc/apt/sources.list.d
DebianExtendListDirBackup=/etc/apt/sources.list.d.bak
RedHatReposDir=/etc/yum.repos.d
RedHatReposDirBackup=/etc/yum.repos.d.bak
SelinuxConfig=/etc/selinux/config

RED='\033[31m'
GREEN='\033[32m'
YELLOW='\033[33m'
BLUE='\033[34m'
PLAIN='\033[0m'
BOLD='\033[1m'
SUCCESS='[\033[32mOK\033[0m]'
COMPLETE='[\033[32mDONE\033[0m]'
WARN='[\033[33mWARN\033[0m]'
ERROR='[\033[31mERROR\033[0m]'
WORKING='[\033[34m*\033[0m]'


## 系统判定变量
function EnvJudgment() {
    ## 判定当前系统基于 Debian or RedHat
    if [ -s $RedHatRelease ]; then
        SYSTEM_FACTIONS=${SYSTEM_REDHAT}
    elif [ -s $DebianVersion ]; then
        SYSTEM_FACTIONS=${SYSTEM_DEBIAN}
    else
        echo -e "\n$ERROR 无法判断当前运行环境，请先确认本脚本针对当前操作系统是否适配\n"
        exit
    fi
    ## 定义系统名称
    SYSTEM_NAME=$(cat $LinuxRelease | grep -E "^NAME=" | awk -F '=' '{print$2}' | sed "s/[\'\"]//g")
    ## 定义系统版本号
    SYSTEM_VERSION_NUMBER=$(cat $LinuxRelease | grep -E "VERSION_ID=" | awk -F '=' '{print$2}' | sed "s/[\'\"]//g")
    ## 判定系统名称、版本、版本号
    case ${SYSTEM_FACTIONS} in
    Debian)
        if [ ! -x /usr/bin/lsb_release ]; then
            apt-get install -y lsb-release
            if [ $? -eq 0 ]; then
                clear
            else
                echo -e "\n$ERROR lsb-release 软件包安装失败"
                echo -e "\n本脚本需要通过 lsb_release 指令判断系统类型，当前可能为精简安装的系统一般系统自带，请自行安装后重新执行脚本！\n"
                exit
            fi
        fi
        SYSTEM_JUDGMENT=$(${DebianRelease} -is)
        SYSTEM_VERSION=$(${DebianRelease} -cs)
        ;;
    RedHat)
        SYSTEM_JUDGMENT=$(cat $RedHatRelease | sed 's/ //g' | cut -c1-6)
        if [[ ${SYSTEM_JUDGMENT} = ${SYSTEM_CENTOS} || ${SYSTEM_JUDGMENT} = ${SYSTEM_RHEL} ]]; then
            CENTOS_VERSION=$(echo ${SYSTEM_VERSION_NUMBER} | cut -c1)
        else
            CENTOS_VERSION=""
        fi
        ;;
    esac
    ## 判定系统处理器架构
    case ${ARCH} in
    x86_64)
        SYSTEM_ARCH="x86_64"
        ;;
    aarch64)
        SYSTEM_ARCH="ARM64"
        ;;
    armv7l)
        SYSTEM_ARCH="ARMv7"
        ;;
    armv6l)
        SYSTEM_ARCH="ARMv6"
        ;;
    i686)
        SYSTEM_ARCH="x86_32"
        ;;
    *)
        SYSTEM_ARCH=${ARCH}
        ;;
    esac
    ## 定义软件源分支名称
    if [ ${SYSTEM_JUDGMENT} = ${SYSTEM_UBUNTU} ]; then
        if [ ${ARCH} = "x86_64" ] || [ ${ARCH} = "*i?86*" ]; then
            SOURCE_BRANCH=${SYSTEM_JUDGMENT,,}
        else
            SOURCE_BRANCH=ubuntu-ports
        fi
    elif [ ${SYSTEM_JUDGMENT} = ${SYSTEM_RHEL} ]; then
        SOURCE_BRANCH="centos"
    else
        SOURCE_BRANCH=${SYSTEM_JUDGMENT,,}
    fi
    ## 定义软件源同步/更新文字
    case ${SYSTEM_FACTIONS} in
    Debian)
        SYNC_TXT="更新"
        ;;
    RedHat)
        SYNC_TXT="同步"
        ;;
    esac
    case ${SYSTEM_NAME} in
    Ubuntu)
        PKG_MGR=apt-get
        ;;
    CentOS)
        PKG_MGR=yum
        ;;
    esac
}

echo $SYSTEM_JUDGMENT

set -e

spatialPrint() {
    echo ""
    echo ""
    echo "$1"
	echo "================================"
}

# To note: the execute() function doesn't handle pipes well
execute () {
	echo "$ $*"
	OUTPUT=$($@ 2>&1)
	if [ $? -ne 0 ]; then
        echo "$OUTPUT"
        echo ""
        echo "Failed to Execute $*" >&2
        exit 1
    fi
}

# Speed up the process
# Env Var NUMJOBS overrides automatic detection
if [[ -n $NUMJOBS ]]; then
    MJOBS=$NUMJOBS
elif [[ -f /proc/cpuinfo ]]; then
    MJOBS=$(grep -c processor /proc/cpuinfo)
elif [[ "$OSTYPE" == "darwin"* ]]; then
	MJOBS=$(sysctl -n machdep.cpu.thread_count)
else
    MJOBS=4
fi

sudo $PKG_MGR install wget dos2unix
sudo wget https://gitee.com/SuperManito/LinuxMirrors/raw/main/ChangeMirrors.sh
sudo chmod +x ChangeMirrors.sh
sudo dos2unix ChangeMirrors.sh
sudo ./ChangeMirrors.sh

sudo $PKG_MGR update -y
if [[ ! -n $CIINSTALL ]]; then
    sudo $PKG_MGR upgrade -y
    #sudo $PKG_MGR install ubuntu-restricted-extras -y
fi

# Choice for terminal that will be adopted: Tilda+tmux
# Not guake because tilda is lighter on resources
# Not terminator because tmux sessions continue to run if you accidentally close the terminal emulator
sudo $PKG_MGR install git curl -y
sudo $PKG_MGR install tilda tmux byobu -y
sudo $PKG_MGR install gimp -y
sudo $PKG_MGR install cron dnsutils unzip lrzsz fdisk gdisk exfat-fuse exfat-utils mlocate -y
sudo $PKG_MGR install net-tools -y
sudo $PKG_MGR install software-properties-common -y
sudo $PKG_MGR install python3-pip -y
sudo $PKG_MGR install xclip xsel -y # this is used for the copying tmux buffer to clipboard buffer
#execute sudo $PKG_MGR install vim-gui-common vim-runtime -y
sudo $PKG_MGR install vim -y
# Install dependancies
sudo $PKG_MGR install build-essential checkinstall
sudo $PKG_MGR install libreadline-gplv2-dev libncursesw5-dev libssl-dev libsqlite3-dev tk-dev libgdbm-dev libc6-dev libbz2-dev

# Retrieve and unzip package
wget https://www.python.org/ftp/python/3.6.0/Python-3.6.0.tar.xz
tar xvf Python-3.6.0.tar.xz

# Make
cd Python-3.6.0/
./configure
sudo make altinstall
echo 'alias python="python3"' >> ~/.bash_profile
. ~/.bash_profile

sudo pip install cheat

# config vim
mkdir .vim
cd .vim
mkdir bundle
cd bundle
git clone https://ghproxy.com/https://github.com/VundleVim/Vundle.vim.git
cd ~/
wget https://zll17.github.io/assets/zll.vimrc -O .vimrc
#cp ./config_files/vimrc ~/.vimrc


# refer : [http://www.rushiagr.com/blog/2016/06/16/everything-you-need-to-know-about-tmux-copy-pasting-ubuntu/] for tmux buffers in ubuntu
cp ./config_files/tmux.conf ~/.tmux.conf
cp ./config_files/tmux.conf.local ~/.tmux.conf.local
mkdir -p ~/.config/tilda
cp ./config_files/config_0 ~/.config/tilda/

#Checks if ZSH is partially or completely Installed to Remove the folders and reinstall it
rm -rf ~/.z*
zsh_folder=/opt/.zsh/
if [[ -d $zsh_folder ]];then
	sudo rm -r /opt/.zsh/*
fi

spatialPrint "Setting up Zsh + Zim now"
sudo $PKG_MGR install zsh -y
sudo mkdir -p /opt/.zsh/ && sudo chmod ugo+w /opt/.zsh/
export ZIM_HOME=/opt/.zsh/zim
curl -fsSL https://raw.githubusercontent.com/zimfw/install/master/install.zsh | zsh
# Change default shell to zsh
command -v zsh | sudo tee -a /etc/shells
sudo chsh -s "$(command -v zsh)" "${USER}"

sudo $PKG_MGR install aria2 -y

# Create bash aliases
cp ./config_files/bash_aliases /opt/.zsh/bash_aliases >/dev/null  # Suppress error messages in case the file already exists
rm -f ~/.bash_aliases
ln -s /opt/.zsh/bash_aliases ~/.bash_aliases

{
    echo "if [ -f ~/.bash_aliases ]; then"
    echo "  source ~/.bash_aliases"
    echo "fi"

    echo "# Switching to 256-bit colour by default so that zsh-autosuggestion's suggestions are not suggested in white, but in grey instead"
    echo "export TERM=xterm-256color"
} >> ~/.zshrc

# Now create shortcuts
#execute sudo $PKG_MGR install run-one xbindkeys xbindkeys-config wmctrl xdotool -y
#cp ./config_files/xbindkeysrc ~/.xbindkeysrc

# Now download and install bat
spatialPrint "Installing bat, a handy replacement for cat"
latest_bat_setup=$(curl --silent "https://api.github.com/repos/sharkdp/bat/releases/latest" | grep "deb" | grep "browser_download_url" | head -n 1 | cut -d \" -f 4)
aria2c --file-allocation=none -c -x 10 -s 10 --dir /tmp -o bat.deb $latest_bat_setup
sudo dpkg -i /tmp/bat.deb
sudo $PKG_MGR install -f

# Check if Anaconda's Miniconda is already installed
#if [[ -n $(echo $PATH | grep 'conda') ]]; then
#    echo "Anaconda is already installed, skipping installation"
#    echo "To reinstall, delete the Anaconda install directory (/opt/anaconda3 if done by this script) and remove from PATH as well"
#else
#
#    spatialPrint "Installing the latest Anaconda Python in /opt/anaconda3"
#    latest_anaconda_setup="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh"
#    aria2c --file-allocation=none -c -x 10 -s 10 -o anacondaInstallScript.sh --dir ./extras ${continuum_website}${latest_anaconda_setup}
#    sudo mkdir -p /opt/anaconda3 && sudo chmod ugo+w /opt/anaconda3
#    execute bash ./extras/anacondaInstallScript.sh -f -b -p /opt/anaconda3
#
#    spatialPrint "Setting up your anaconda"
#    execute /opt/anaconda3/bin/conda update conda -y
#    execute /opt/anaconda3/bin/conda clean --all -y
#    execute /opt/anaconda3/bin/conda install anaconda -y
#    execute /opt/anaconda3/bin/conda install ipython -y
#
#    execute /opt/anaconda3/bin/conda install libgcc -y
#    execute /opt/anaconda3/bin/pip install numpy scipy matplotlib scikit-learn scikit-image jupyter notebook pandas h5py cython jupyterlab
#    execute /opt/anaconda3/bin/pip install msgpack
#    execute /opt/anaconda3/bin/conda install line_profiler -y
#    sed -i.bak "/anaconda3/d" ~/.zshrc
#
#    /opt/anaconda3/bin/conda info -a
#
#    spatialPrint "Adding anaconda to path variables"
#    {
#        echo "# Anaconda Python. Change the \"conda activate base\" to whichever environment you would like to activate by default"
#        echo ". /opt/anaconda3/etc/profile.d/conda.sh"
#        echo "conda activate base"
#    } >> ~/.zshrc
#
#fi # Anaconda Installation end

# echo "*************************** NOTE *******************************"
# echo "If you ever mess up your anaconda installation somehow, do"
# echo "\$ conda remove anaconda matplotlib mkl mkl-service nomkl openblas"
# echo "\$ conda clean --all"
# echo "Do this for each environment as well as your root. Then reinstall all except nomkl"

# For utilities such as lspci
#execute sudo $PKG_MGR install pciutils

## Detect if an Nvidia card is attached, and install the graphics drivers automatically if not already installed
#if [[ -n $(lspci | grep -i nvidia) && ! $(command -v nvidia-smi) ]]; then
#    spatialPrint "Installing Display drivers and any other auto-detected drivers for your hardware"
#    execute sudo add-apt-repository ppa:graphics-drivers/ppa -y
#    execute sudo $PKG_MGR update
#    execute sudo ubuntu-drivers autoinstall
#fi

ssh-keygen
echo ">>> SSH Pub Key:"
cat ~/.ssh/id_rsa.pub

spatialPrint "The script has finished. Please enter credentials to access your new shell"
if [[ ! -n $CIINSTALL ]]; then
    su - $USER
fi
