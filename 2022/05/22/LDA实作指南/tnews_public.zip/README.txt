2021年7月25日：更新了测试集。

具体内容：
原有测试集更名为test1.0.json，新的测试集命名为test.json（具体版本为1.1）
7月25日之后，新提交的测试集，需在新的测试集(test.json)上做预测并提交。其中提交的文件命名没有变化，还是tnews_predict.json。
原有测试集只用于测试或备份。

更多信息见CLUE：www.CLUEbenchmarks.com，或项目https://github.com/CLUEbenchmark/CLUE；如有问题也可以邮件联系：CLUEbenchmark@163.com