import os,subprocess
import multiprocessing as mp 

def run(f="hello"):
    exe = "./orgeth_ktidle"
    ag = "52"
    subprocess.run([exe,ag])

pl = mp.Pool(1)
pl.map_async(run,('world',))
pl.join()